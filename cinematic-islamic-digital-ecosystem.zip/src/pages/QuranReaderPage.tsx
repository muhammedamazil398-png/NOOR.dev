import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import { SURAHS } from '../data/surahs';
import RainbowButton from '../components/RainbowButton';
import ContextPopup from '../components/ContextPopup';

interface Ayah { number: number; numberInSurah: number; text: string; juz: number; }
interface TranslationAyah { numberInSurah: number; text: string; }

const RECITERS = [
  { id: 'ar.alafasy', name: 'Mishary Alafasy' },
  { id: 'ar.abdurrahmaansudais', name: 'Abdurrahman As-Sudais' },
  { id: 'ar.abdulbasitmurattal', name: 'Abdul Basit (Murattal)' },
  { id: 'ar.husary', name: 'Mahmoud Khalil Al-Husary' },
  { id: 'ar.minshawi', name: 'Mohamed Siddiq Al-Minshawi' },
];

export default function QuranReaderPage() {
  const setPage = useAppStore(s => s.setPage);
  const currentSurah = useAppStore(s => s.currentSurah);
  const setCurrentSurah = useAppStore(s => s.setCurrentSurah);
  const surahInfo = SURAHS.find(s => s.number === currentSurah)!;

  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [translations, setTranslations] = useState<TranslationAyah[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAyah, setSelectedAyah] = useState<number | null>(null);
  const [showTranslation, setShowTranslation] = useState(true);
  const [reciter, setReciter] = useState(RECITERS[0].id);
  const [showReciterMenu, setShowReciterMenu] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioEl, setAudioEl] = useState<HTMLAudioElement | null>(null);

  // Context popup state
  const [popup, setPopup] = useState<{ show: boolean; x: number; y: number; ayahNum: number; tafsirText: string; loading: boolean }>({
    show: false, x: 0, y: 0, ayahNum: 0, tafsirText: '', loading: false
  });

  useEffect(() => {
    setLoading(true); setAyahs([]); setTranslations([]);
    Promise.all([
      fetch(`https://api.alquran.cloud/v1/surah/${currentSurah}/quran-uthmani`).then(r => r.json()),
      fetch(`https://api.alquran.cloud/v1/surah/${currentSurah}/en.asad`).then(r => r.json()),
    ]).then(([arabic, english]) => {
      if (arabic.data?.ayahs) setAyahs(arabic.data.ayahs);
      if (english.data?.ayahs) setTranslations(english.data.ayahs);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [currentSurah]);

  const openTafsir = useCallback(async (e: React.MouseEvent, ayahNum: number) => {
    e.stopPropagation();
    const rect = { x: e.clientX, y: e.clientY };
    setPopup({ show: true, x: rect.x, y: rect.y, ayahNum, tafsirText: '', loading: true });
    try {
      const res = await fetch(`https://api.alquran.cloud/v1/ayah/${currentSurah}:${ayahNum}/en.asad`);
      const data = await res.json();
      setPopup(p => ({ ...p, tafsirText: data.data?.text || 'Translation unavailable.', loading: false }));
    } catch {
      setPopup(p => ({ ...p, tafsirText: 'Could not load. Please check your connection.', loading: false }));
    }
  }, [currentSurah]);

  const playAyah = (ayahGlobalNum: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (audioEl) audioEl.pause();
    const audio = new Audio(`https://cdn.islamic.network/quran/audio/128/${reciter}/${ayahGlobalNum}.mp3`);
    audio.play().catch(() => {});
    audio.onended = () => setIsPlaying(false);
    setAudioEl(audio);
    setIsPlaying(true);
  };

  const stopAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (audioEl) { audioEl.pause(); setIsPlaying(false); }
  };

  const goToSurah = (n: number) => {
    if (n >= 1 && n <= 114) {
      setCurrentSurah(n); setSelectedAyah(null);
      setPopup(p => ({ ...p, show: false }));
      window.scrollTo(0, 0);
    }
  };

  return (
    <div className="min-h-screen pb-28">
      {/* Context popup for tafsir */}
      <ContextPopup
        show={popup.show}
        onClose={() => setPopup(p => ({ ...p, show: false }))}
        anchorX={popup.x}
        anchorY={popup.y}
      >
        <div className="pr-6">
          <p className="text-amber-200/60 text-xs font-medium mb-1">
            Tafsir — Ayah {popup.ayahNum}
          </p>
          <p className="text-white/20 text-[10px] mb-3">{surahInfo.englishName} · {surahInfo.revelationType}</p>
          <div className="divider-gold mb-3" />

          {/* Arabic ayah */}
          {ayahs.find(a => a.numberInSurah === popup.ayahNum) && (
            <p className="font-arabic text-lg text-amber-200/50 text-right leading-9 mb-3">
              {ayahs.find(a => a.numberInSurah === popup.ayahNum)!.text}
            </p>
          )}
          <div className="divider-gold mb-3" />

          {popup.loading ? (
            <div className="flex items-center justify-center py-6">
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                className="w-5 h-5 rounded-full border-2 border-amber-200/10 border-t-amber-200/50" />
            </div>
          ) : (
            <>
              <p className="text-emerald-300/30 text-[9px] uppercase tracking-[0.2em] mb-1.5">Translation & Commentary</p>
              <p className="text-white/55 text-[13px] leading-relaxed font-light">{popup.tafsirText}</p>
              <div className="mt-3 py-2 px-3 glass rounded-lg">
                <p className="text-white/20 text-[10px]">
                  Surah {surahInfo.englishName} · Ayah {popup.ayahNum} · Juz {ayahs.find(a => a.numberInSurah === popup.ayahNum)?.juz || '—'}
                </p>
              </div>
            </>
          )}
        </div>
      </ContextPopup>

      {/* Sticky Header */}
      <div className="sticky top-0 z-30 glass-strong px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setPage('quran')}
              className="w-9 h-9 glass rounded-lg flex items-center justify-center cursor-pointer">
              <svg className="w-4 h-4 text-white/60" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </motion.button>
            <div>
              <h2 className="font-arabic text-lg text-amber-200/80">{surahInfo.name}</h2>
              <p className="text-white/30 text-[10px]">{surahInfo.englishName} — {surahInfo.numberOfAyahs} ayahs</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <motion.button whileTap={{ scale: 0.9 }}
              onClick={() => setShowTranslation(!showTranslation)}
              className={`px-3 py-1.5 rounded-lg text-xs cursor-pointer transition-all
                ${showTranslation ? 'bg-amber-500/12 text-amber-200 border border-amber-500/15' : 'glass text-white/25'}`}>
              EN
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }}
              onClick={() => setShowReciterMenu(!showReciterMenu)}
              className="w-9 h-9 glass rounded-lg flex items-center justify-center cursor-pointer">
              <svg className="w-4 h-4 text-white/35" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55C7.79 13 6 14.79 6 17s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
              </svg>
            </motion.button>
          </div>
        </div>
        <AnimatePresence>
          {showReciterMenu && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }} className="mt-2 overflow-hidden">
              <div className="glass rounded-xl p-1.5 space-y-0.5">
                {RECITERS.map(r => (
                  <button key={r.id}
                    onClick={() => { setReciter(r.id); setShowReciterMenu(false); }}
                    className={`w-full px-4 py-2.5 rounded-lg text-left text-sm transition-all cursor-pointer
                      ${reciter === r.id ? 'bg-amber-500/10 text-amber-200' : 'text-white/45 hover:bg-white/[0.03]'}`}>
                    {r.name}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bismillah */}
      {currentSurah !== 9 && (
        <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }}
          className="text-center py-8">
          <p className="font-arabic text-2xl md:text-3xl text-amber-200/50 text-glow-gold">
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </p>
          <div className="divider-gold w-48 mx-auto mt-5" />
        </motion.div>
      )}

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-20">
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
            className="w-8 h-8 rounded-full border-2 border-amber-200/10 border-t-amber-200/50" />
        </div>
      )}

      {/* Ayahs */}
      <div className="px-4 md:px-8 space-y-1 py-2">
        {ayahs.map((ayah, i) => {
          const translation = translations[i];
          const isSelected = selectedAyah === ayah.numberInSurah;

          return (
            <motion.div key={ayah.numberInSurah}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              transition={{ delay: Math.min(i * 0.012, 0.3) }}
              onClick={() => setSelectedAyah(isSelected ? null : ayah.numberInSurah)}
              className={`rounded-2xl p-4 md:p-5 transition-all duration-500 cursor-pointer
                ${isSelected ? 'glass' : 'hover:bg-white/[0.015]'}`}
              style={isSelected ? { boxShadow: '0 0 40px rgba(212,168,83,0.03)' } : {}}>
              
              {/* Ayah number + controls */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-full glass flex items-center justify-center text-[10px] text-amber-200/40 font-medium">
                    {ayah.numberInSurah}
                  </span>
                  {isSelected && (
                    <div className="flex items-center gap-1.5">
                      <motion.button
                        initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => isPlaying ? stopAudio(e) : playAyah(ayah.number, e)}
                        className="w-7 h-7 rounded-full bg-amber-500/8 flex items-center justify-center cursor-pointer border border-amber-500/10">
                        <svg className="w-3 h-3 text-amber-200/60" fill="currentColor" viewBox="0 0 24 24">
                          {isPlaying ? <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/> : <path d="M8 5v14l11-7z"/>}
                        </svg>
                      </motion.button>
                      <motion.button
                        initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.05 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={(e) => openTafsir(e, ayah.numberInSurah)}
                        className="w-7 h-7 rounded-full bg-emerald-500/8 flex items-center justify-center cursor-pointer border border-emerald-500/10"
                        title="View Tafsir">
                        <svg className="w-3 h-3 text-emerald-300/60" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                      </motion.button>
                    </div>
                  )}
                </div>
                <span className="text-white/8 text-[9px]">Juz {ayah.juz}</span>
              </div>

              {/* Arabic */}
              <p className="quran-text text-amber-100/80 mb-3">
                {ayah.text} <span className="text-amber-200/15 text-lg">﴿{ayah.numberInSurah}﴾</span>
              </p>

              {/* Translation */}
              {showTranslation && translation && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="text-white/35 text-[13px] leading-relaxed border-t border-white/[0.03] pt-3 font-light">
                  {translation.text}
                </motion.p>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Surah navigation */}
      {!loading && ayahs.length > 0 && (
        <div className="flex items-center justify-between px-6 py-8 gap-3">
          {currentSurah > 1 ? (
            <RainbowButton onClick={() => goToSurah(currentSurah - 1)} size="sm">
              {SURAHS[currentSurah - 2]?.englishName}
            </RainbowButton>
          ) : <div />}
          {currentSurah < 114 ? (
            <RainbowButton onClick={() => goToSurah(currentSurah + 1)} size="sm">
              {SURAHS[currentSurah]?.englishName}
            </RainbowButton>
          ) : <div />}
        </div>
      )}
    </div>
  );
}
